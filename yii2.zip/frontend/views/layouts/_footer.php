<p class="pull-right"><a href="#"><strong>Наверх</strong></a></p>
<p>© 2016 Сеть ветеринарных клиник <a href="index.php"><strong>Ветзоолэнд</strong></a></p>
