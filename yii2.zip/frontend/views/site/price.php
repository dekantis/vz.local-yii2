<p align=center>   <iframe
    src="http://docs.google.com/gview?url=http://vetzooland.by/Items/2.doc&embedded=true"
    style="width:800px; height:800px;"
    frameborder="1"
></iframe>
  </p>
